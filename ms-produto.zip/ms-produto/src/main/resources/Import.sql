

INSERT INTO tb_produto (nome, descricao, valor) VALUES ('Smart TV', 'Smart TV LG LED 50 polegadas', 2285.0);
INSERT INTO tb_produto (nome, descricao, valor) VALUES ('Mouse Microsoft', 'Mouse sem fio', 250.0);
INSERT INTO tb_produto (nome, descricao, valor) VALUES ('Teclado Microsoft', 'Teclado sem fio', 278.95);
INSERT INTO tb_produto (nome, descricao, valor) VALUES ('Smartphone Samsung Galaxy A54 5G', 'Samsung Galaxy A54 5G', 1799.0);
INSERT INTO tb_produto (nome, descricao, valor) VALUES ('Smart TV', 'Samsung Vision AI TV 85" QLED Ultra 4K Q7F 2025', 8799);
INSERT INTO tb_produto (nome, descricao, valor) VALUES ('Teclado Logitech', 'Teclado sem fio', 358.0);
INSERT INTO tb_produto (nome, descricao, valor) VALUES ('Apple iPhone 17', 'Apple iPhone 17, 256G, Azul Névoa', 7999.00);

